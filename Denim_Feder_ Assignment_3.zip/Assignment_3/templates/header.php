<!-- Get signed in user -->
<?php $user = $_SERVER['REMOTE_USER']; ?>

<!-- Logout alert -->
<script>
function logoutAlert() {
    alert("\n LOGGING OUT!\n\nPassword will be remembered until browser is closed.\n")
}
</script>

<!-- Header display -->
<div class="text-light bg-dark sticky-top w-100">
    <nav class="navbar navbar-dark d-flex justify-space-around">
        <a class="navbar-brand d-flex"
            href="<?php if($user == 'Admin'){echo '/Assignment_3/admin/admin.php';} elseif ($user == NULL){echo '/Assignment_3/public/index.php';}; ?>">
            <img style="width:80px; height:80px;" class="image-fluid pt-1 mr-3"
                src="../logo/Logo_of_the_SCP_Foundation.png" />
            <div class="remove-300">
                <h1 style="font-family: 'Volkhov', serif;">S C P <span class="remove-500">Foundation</span></h1>
                <h6 class="">Secure, Contain, Protect</h6>
            </div>
        </a>
        <a class="navbar-brand navbar-right"
            href="<?php if($user == 'Admin'){echo '/Assignment_3/public/index.php';} elseif ($user == NULL){echo '/Assignment_3/admin/admin.php';}; ?>"
            onclick='<?php if($user == 'Admin'){echo 'logoutAlert()';} elseif ($user == NULL){echo '';}; ?>'>
            <h3><?php if($user == 'Admin'){echo 'Logout';} elseif ($user == NULL){echo 'Login';}; ?>
            </h3>
        </a>
    </nav>
</div>