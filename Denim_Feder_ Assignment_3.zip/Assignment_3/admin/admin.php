<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
        integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <!-- CSS link -->
    <link rel="stylesheet" href="../styles/style.css">
    <title>ADMIN | SCP Foundation DB</title>
</head>

<body class="bg-secondary h-100">

    <!-- HEADER -->
    <?php   include '../templates/header.php';  ?>

    <!-- MVC new objects -->
    <?php   
        include 'adminMVC.php'; 
        $model = new Model();              
        $controller = new Controller($model);
        $view = new View($model); 
    ?>

    <!-- PAGE DISPLAY template-->
    <div class='container'>
        <br>
        <div class='card border p-1 bg-dark'>
            <div class='card-header bg-light'>
                <h3 class='pt-1 text-center'>SCP Foundation Admin</h3>
            </div>
        </div>
        <div id='accordion' class='card bg-dark shadow'>
            <!-- Call page display -->
            <?php
                //if page is set in adress bar save it to $page      
                if(isset($_GET['page'])){$page = $_GET['page'];} else {$page = NULL;}       
                //page display if statement
                if ($page == 'create'){$view->create();} elseif ($page == NULL) {$view->output();}                  
            ?>
        </div>
    </div>
    <br>
    <br>

    <!-- FOOTER -->
    <?php   include '../templates/footer.php';  ?>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
        integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"
        integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous">
    </script>
</body>

</html>