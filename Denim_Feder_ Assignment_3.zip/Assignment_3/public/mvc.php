<script>
function ResctrictedCheck() {
    if (confirm("\nWARNING This is restricted content!\n\nDo you wish to login to Admin?.")) {
        window.location.assign("https://30019329.2020.labnet.nz/Assignment_3/admin/admin.php");
    } else {
        window.location.assign("https://30019329.2020.labnet.nz/Assignment_3/public/index.php");
    };
}
</script>

<?php

    class Model
    {
       // This variable holds your data and has to be public so that other classes can access it
        public $data;
        
        public function __construct()
        {
          // change the variable value below to decode the json file that is provided in the assignment.
          $this->data = json_decode(file_get_contents('../admin/JSON/scp.json'));           
        } // end function
    } 
    
    // View class is complete, no changes neccessary
    class View
    {
        private $model;
        
        public function __construct(Model $model)
        {
            $this->model = $model;
        }
        
        public function output()
        {
            $count = 1;                                                             
            foreach($this->model->data as $object){
                if ($object->restricted == 'true')
                {
                    echo 
                    "
                            <div class='card bg-dark'>
                                <div class='card bg-danger p-1'>
                                    <a class='card-header btn bg-light' onclick='ResctrictedCheck()'>
                                        <span class='h5'>$object->item (Restricted)</span>
                                    </a>
                                </div>
                                <div id='collapse$count' class='collapse' data-parent='#accordion'>
                                </div>
                            </div>
                    ";                
                }
                else
                {
                    echo 
                    "
                            <div class='card bg-dark'>
                                <div class='card bg-secondary p-1'>
                                    <a class='card-header btn bg-light' data-toggle='collapse' href='#collapse$count'>
                                        <span class='h5'>$object->item</span>
                                    </a>
                                </div>
                                <div id='collapse$count' class='collapse' data-parent='#accordion'>
                                    <div class='card p-1 bg-secondary'>
                                        <div class='bg-light'>
                                            <br>
                                            <h4 class='text-center'>Class - <span class='h4'>$object->class</span></h4>
                                            <br>
                                            <div class='card bg-secondary conatainer-fluid'></div>
                                            <br>
                                            <h4 class='text-center'>Containment</h4>
                                            <p class='card-body'>$object->containment</p>
                                            <div class='card bg-secondary conatainer-fluid'></div>
                                            <br>  
                                            <h4 class='text-center'>Description</h4>
                                            <p class='card-body'>$object->desc</p>                                         
                                        </div>                                       
                                    </div>
                                </div>
                            </div>
                    ";                
                }                                            
            };               
            $count++;
        }    
    }
    
    // Controller class is complete, no changes neccessary
    class Controller
    {
        private $model;
       
        public function __construct(Model $model)
        {
            $this->model = $model;
        }
    }
?>